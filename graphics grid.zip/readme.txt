den exw kati na pw 
aplws einai pio programmatistiko na vazw ena readme
aplws vevaiwthite oti ola vriskontai ston idio fakelo kserwgw
poutses ble
